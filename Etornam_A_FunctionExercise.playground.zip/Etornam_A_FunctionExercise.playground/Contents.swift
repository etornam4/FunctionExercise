import UIKit
func justMathin (a: Int, b: Int) -> Int {
    return a + b
}
var addition: (Int, Int) -> Int = justMathin
print("Result: \(addition( 5, 4))")
